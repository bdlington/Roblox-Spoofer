﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Principal;
using System.Threading;
using Microsoft.Win32;
using System.Windows.Forms;

namespace Spoofer
{
    internal class Program
    {
        [STAThread]
        static void Main()
        {
            if (!IsAdministrator())
            {
                RelaunchAsAdmin();
                return;
            }

            try
            {
                CloseRoblox();
                Console.WriteLine("Roblox process closed.");
                ClearRobloxData();
                Console.WriteLine("Roblox local data cleared.");
                SpoofMacAutomatically();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        static void RelaunchAsAdmin()
        {
            ProcessStartInfo psi = new ProcessStartInfo
            {
                FileName = Process.GetCurrentProcess().MainModule.FileName,
                UseShellExecute = true,
                Verb = "runas"
            };
            try
            {
                Process.Start(psi);
            }
            catch
            {
                MessageBox.Show("Administrator privileges are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Environment.Exit(0);
        }

        static void CloseRoblox()
        {
            var robloxProcesses = Process.GetProcessesByName("RobloxPlayerBeta")
                .Concat(Process.GetProcessesByName("RobloxGameClient"));
            foreach (var process in robloxProcesses)
            {
                if (!process.HasExited)
                {
                    process.Kill();
                    process.WaitForExit(5000);
                    Console.WriteLine($"Terminated process: {process.ProcessName}");
                }
            }
        }

        static void ClearRobloxData()
        {
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string roamingAppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

            string[] localFolders = {
                Path.Combine(localAppData, "Roblox", "Cache"),
                Path.Combine(localAppData, "Roblox", "Logs"),
                Path.Combine(localAppData, "Roblox", "ClientSettings")
            };

            string settingsFile = Path.Combine(localAppData, "Roblox", "GlobalBasicSettings_13.xml");

            string[] roamingFolders = {
                Path.Combine(roamingAppData, "Roblox", "Settings")
            };

            foreach (string folder in localFolders)
                if (Directory.Exists(folder))
                    try { Directory.Delete(folder, true); Console.WriteLine($"Deleted folder: {folder}"); } catch { }

            foreach (string folder in roamingFolders)
                if (Directory.Exists(folder))
                    try { Directory.Delete(folder, true); Console.WriteLine($"Deleted folder: {folder}"); } catch { }

            if (File.Exists(settingsFile))
                try { File.Delete(settingsFile); Console.WriteLine($"Deleted file: {settingsFile}"); } catch { }
        }

        static string GenerateRandomMac()
        {
            string[] secondDigits = { "2", "6", "A", "E" };
            Random rnd = new Random();
            string firstByte = rnd.Next(0, 16).ToString("X") + secondDigits[rnd.Next(secondDigits.Length)];
            string newMac = firstByte;
            for (int i = 0; i < 5; i++)
                newMac += rnd.Next(0, 256).ToString("X2");
            return newMac;
        }

        static string GetMacAddress(string adapterName)
        {
            var adapter = NetworkInterface.GetAllNetworkInterfaces()
                .FirstOrDefault(n => n.Name == adapterName);
            if (adapter == null) return "Not Found";
            return string.Join(":", adapter.GetPhysicalAddress().GetAddressBytes().Select(b => b.ToString("X2")));
        }

        static void SpoofMacAutomatically()
        {
            var adapters = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n => n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .ToArray();

            Console.WriteLine("Available network adapters:");
            for (int i = 0; i < adapters.Length; i++)
                Console.WriteLine($"{i}: {adapters[i].Name} - {adapters[i].Description}");

            Console.Write("Select adapter index to spoof MAC: ");
            if (!int.TryParse(Console.ReadLine(), out int index) || index < 0 || index >= adapters.Length)
            {
                Console.WriteLine("Invalid selection.");
                return;
            }

            var adapter = adapters[index];
            string adapterName = adapter.Name;
            Console.WriteLine($"Selected adapter: {adapterName}");

            string baseRegPath = @"SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}";
            using (RegistryKey baseKey = Registry.LocalMachine.OpenSubKey(baseRegPath, true))
            {
                if (baseKey == null) { Console.WriteLine("Failed to open adapter registry base key."); return; }

                string targetSubKey = null;
                foreach (string subKeyName in baseKey.GetSubKeyNames())
                {
                    using (RegistryKey subKey = baseKey.OpenSubKey(subKeyName))
                    {
                        if (subKey == null) continue;
                        string driverDesc = subKey.GetValue("DriverDesc") as string;
                        if (driverDesc != null && driverDesc.IndexOf(adapter.Description, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            targetSubKey = subKeyName;
                            break;
                        }
                    }
                }

                if (targetSubKey == null) { Console.WriteLine("Adapter registry key not found."); return; }

                string regPath = $"{baseRegPath}\\{targetSubKey}";
                string newMac = GenerateRandomMac();
                Console.WriteLine($"Spoofing to: {newMac}");

                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(regPath, true))
                    if (key != null) key.SetValue("NetworkAddress", newMac, RegistryValueKind.String);

                ExecuteCommand($"netsh interface set interface \"{adapterName}\" disable");
                Thread.Sleep(1000);
                ExecuteCommand($"netsh interface set interface \"{adapterName}\" enable");
                Thread.Sleep(1000);

                string updatedMac = GetMacAddress(adapterName);
                Console.WriteLine($"MAC Address is now: {updatedMac}");

                if (updatedMac.Replace(":", "").ToUpper() == newMac)
                    MessageBox.Show("Successfully Spoofed MAC Address!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to change MAC Address.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static void ExecuteCommand(string command)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/C " + command)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            using (Process process = Process.Start(psi))
                process.WaitForExit();
        }
    }
}
